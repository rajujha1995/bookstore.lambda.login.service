# lambda-login-service
A simple login service that uses AWS lambda and DynamoDB.
